# 许可与历史说明 / Licensing notes

本修改版包含来自 DavidXanatos/wumgr 的 GNU GPLv3 代码；v5 完整包中也已携带该许可。v6 在根目录提供对应的 [GPLv3 完整文本](../../LICENSE)，并保留完整对应源码及原有版权归属。这不是把上游代码重新许可为 Apache 2.0。

上传 v6 前，GitHub 仓库根目录曾放置 Apache 2.0 模板，与包内 GPLv3 不一致。该历史文本原样保存为 [previous-repository-Apache-2.0.txt](previous-repository-Apache-2.0.txt)，仅作历史记录，不替代此驱动中心及其 GPLv3 上游代码的适用许可。原始提交历史也予以保留。

Downloader 3.1.2 的 MIT 许可见 [third-party/Downloader](../../third-party/Downloader/)。Icons8 归属见 [图标说明](../../wumgr/res/icons8.txt)。第三方组件各自的许可及归属不因本次修改而取消。

The driver center contains GNU GPLv3 code from DavidXanatos/wumgr, and the v5 package already carried that license. v6 places the corresponding GPLv3 text in the repository root and retains source and attribution. An Apache 2.0 template previously present at the root is preserved verbatim for historical reference; it does not replace the license applicable to the GPLv3-derived application. Downloader remains MIT-licensed and original Icons8 attribution remains included.
