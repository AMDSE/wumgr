from pathlib import Path
import hashlib
import shutil
import zipfile

repo = Path(__file__).resolve().parent
out = repo.parent / "wumgr-delivery"
stage = out / "WuMgr-驱动下载中心-v5"
if stage.exists():
    shutil.rmtree(stage)
program = stage / "程序"
source = stage / "源码"
program.mkdir(parents=True)
source.mkdir(parents=True)

release = repo / "wumgr" / "bin" / "Release"
required = ("wumgr.exe", "wumgr.exe.config", "Downloader.dll")
for name in required:
    path = release / name
    if not path.is_file():
        raise FileNotFoundError(f"缺少构建输出: {path}")
    shutil.copy2(path, program / name)
for name in ("LICENSE", "README.zh-CN.md", "PRIVACY_POLICY.md"):
    shutil.copy2(repo / name, program / name)
shutil.copy2(repo / "wumgr" / "res" / "icons8.txt", program / "图标归属.txt")
shutil.copy2(repo / "third-party" / "Downloader" / "LICENSE", program / "Downloader-LICENSE.txt")
shutil.copy2(repo / "third-party" / "Downloader" / "README.md", program / "Downloader-归属说明.md")

# Keep source complete, but never ship package caches or generated build/test output.
excluded_dirs = {".git", "bin", "obj", "packages", "artifacts", ".vs", "__pycache__"}
excluded_names = {"wumgr.exe", "UiTests.exe", "CatalogTests.exe", "ServiceTests.exe",
                  "DeviceTests.exe", "InstallerTests.exe", "PolicyTests.exe"}
for path in repo.rglob("*"):
    rel = path.relative_to(repo)
    if any(part in excluded_dirs for part in rel.parts):
        continue
    if not path.is_file() or path.name in excluded_names or path.suffix in (".log", ".user", ".suo", ".pyc"):
        continue
    target = source / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)

preview = repo / "artifacts" / "中文驱动界面-演示.png"
if preview.exists():
    shutil.copy2(preview, stage / "界面预览-演示数据.png")
log = repo / "artifacts" / "最终测试日志.txt"
if not log.exists():
    raise FileNotFoundError(f"缺少最新测试日志: {log}")
shutil.copy2(log, stage / "自动化测试日志.txt")
(stage / "先读我.txt").write_text(
    "WuMgr 驱动下载中心 · 中文修改版 v5\n\n"
    "运行：在 Windows 10 / 11 解压后打开“程序\\wumgr.exe”，需要 .NET Framework 4.8。\n"
    "下载：使用内置 Downloader 3.1.2，8 块、4 并发；小文件或无 Range 时自动单流。取消/失败会保留 .part 和 .resume.xml，满足条件可恢复。\n"
    "安装：仍使用 WUA 系统缓存，可能另行下载；多线程下载不等于 WUA 安装下载。\n"
    "源码目录不含 packages 缓存、bin/obj 或测试 exe；含 GPLv3、Downloader MIT 许可证及归属。\n"
    "Linux 仅用于自动化测试；Windows 实测待验收。\n", encoding="utf-8")

files = sorted(p for p in stage.rglob("*") if p.is_file())
manifest = [hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(stage).as_posix() for p in files]
(stage / "SHA256SUMS.txt").write_text("\n".join(manifest) + "\n", encoding="utf-8")

archives = [out / "WuMgr-驱动下载中心-v5.zip", out / "WuMgr-驱动下载中心.zip"]
out.mkdir(parents=True, exist_ok=True)
for archive in archives:
    if archive.exists():
        archive.unlink()
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(stage.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(out))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert any(n.endswith("/程序/wumgr.exe") for n in names)
        assert any(n.endswith("/程序/Downloader.dll") for n in names)
        assert any(n.endswith("/源码/tests/ServiceTests.cs") for n in names)
        assert not any(n.endswith(".exe") and "/源码/" in n for n in names)
    print(str(archive))
    print("SHA256:", hashlib.sha256(archive.read_bytes()).hexdigest())
