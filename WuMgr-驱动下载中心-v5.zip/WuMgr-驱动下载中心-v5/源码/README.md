# WuMgr

> 本仓库当前工作版本为 **WuMgr 驱动下载中心 · 中文修改版 v5**。它保留上游 WUA 更新管理功能，并加入设备驱动搜索、可恢复下载与可选后台安装；本修改版不是上游官方发布。

## Overview

WuMgr (Update Manager for Windows) uses the [Windows Update Agent API](https://docs.microsoft.com/en-us/windows/win32/wua_sdk/portal-client) to identify, download and install applicable Microsoft updates. The v5 driver workflow uses the pinned [Downloader 3.1.2](https://github.com/bezzad/Downloader/tree/v3.1.2) library for its separate HTTP download step.

Downloader uses **8 blocks and at most 4 concurrent requests**. It reports speed, aggregate progress and block progress, and limits the memory buffer to **4 MiB**. Files below 256 KiB, or servers without byte-range support, use one stream. Cancellation or failure leaves `.part` and `.resume.xml` files on disk. A later download to the same directory for the same URL can resume only when the server supports Range and supplies a valid strong ETag or Last-Modified; missing validators or a changed resource causes a fresh download. A process crash is not promised to be resumable. A successful non-empty file with the expected length is atomically moved over the final file.

The Downloader package is fixed at 3.1.2/net462, has no external package dependencies, and is not interchangeable with 3.2+ (which is incompatible with this old framework). Its third-party MIT license and attribution are in `third-party/Downloader/` and are copied into releases.

## Installation boundary

Installation still uses the Windows Update Agent system cache and may download separately. The application's multi-threaded HTTP download must not be represented as the WUA installation download. See [the Chinese usage guide](README.zh-CN.md) for the complete behavior and safety notes.

## Build and test

Windows requires Visual Studio 2022, the .NET desktop workload and the .NET Framework 4.8 targeting pack. `build-windows.cmd` restores the pinned package with NuGet when needed and then builds Release. Linux/Mono is for automated testing only; Windows real-device/WUA/CDN verification remains pending acceptance. Run `bash tests/run-tests.sh` on Linux. The test script verifies the pinned package hash, compiles and runs `tests/DownloaderTests.cs`, and retains the existing test suite.

## Upstream

This tool is inspired by [Windows Update Mini Tool](https://www.majorgeeks.com/files/details/windows_update_minitool.html). Icons are provided by [Icons8](http://icons8.com/). See `LICENSE` and `PRIVACY_POLICY.md` for project terms.
