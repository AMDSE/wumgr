@echo off
chcp 65001 >nul
cd /d "%~dp0"
WuMgr.Wpf.Logic.exe > logic-results.txt 2>&1
if errorlevel 1 (type logic-results.txt & pause & exit /b 1)
WuMgr.Wpf.Smoke.exe "%~dp0验收结果"
if errorlevel 1 (echo WPF smoke test failed. Review RESULT.txt. & pause & exit /b 1)
echo Safe demo tests completed. Review logic-results.txt and 验收结果.
pause
